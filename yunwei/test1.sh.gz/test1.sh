#!/bin/bash
# File Name: test1.sh
# Author: Liwqiang
# mail: shrekee@qq.com
# Created Time: Sun 05 Aug 2018 07:01:03 PM CST

echo 'hello, world'
